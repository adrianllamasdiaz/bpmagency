<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$titulo = "BPMagency - queofrecemos";
$fichero = basename(__FILE__);
$directorio = "queofrecemos";

if ($fichero == "index.php") {
    include_once("php/funciones_plantillas.php");
} else {
    include_once("../php/funciones_plantillas.php");
}
crearHeader($directorio, $titulo);
crearMenu($directorio);
?>

<!--   Contenedor Principal    -->

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="container-fluid">
                    <div class="row" id="articulos">
                        <div class="col-md-8">
                            <div class="panel-body introduccion">
                                <p><span class="titulo">Diseño Web Personalizado</span></p>
                                <img src="../img/noticia1.png" alt="Imagen" class="imagennoticia img-responsive">
                            </div>
                            <div class="panel-body text-justify">
                                <p>Ofrecemos diseños de sitios web únicos y personalizados que reflejan la identidad y el estilo de tu local de ocio nocturno. Nuestro objetivo es crear una experiencia de usuario excepcional que atraiga y retenga a tus clientes.<br><br>
                                    <a class="btn btn-primary btn-success" href="nuevasqueofrecemos.php?id=1" role="button">Leer Mas</a></p>
                            </div><hr>
                            <div class="col-md-6">
                                <div class="panel-body"><span class="titulo1">Desarrollo de Aplicaciones Móviles</span><br><img src="../img/noticia1.png" alt="Imagen Jornada" class="imagennoticiaarriba img-responsive">
                                    <a href="nuevasqueofrecemos.php?id=2">Desarrollamos aplicaciones móviles intuitivas y funcionales para que tus clientes puedan interactuar con tu negocio desde cualquier lugar. Facilita la reserva de entradas, la gestión de listas de invitados y la promoción de eventos directamente desde sus dispositivos móviles.</a><br><hr>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="panel-body"><span class="titulo1">Gestión de Redes Sociales</span><br><img src="../img/noticia3.png" alt="Imagen Jornada" class="imagennoticiaarriba img-responsive">
                                    <a href="nuevasqueofrecemos.php?id=3">Nos encargamos de gestionar tus perfiles en redes sociales, creando contenido atractivo y relevante que aumente tu visibilidad y fomente la interacción con tu audiencia. Aprovecha nuestras estrategias para captar más seguidores y convertirlos en clientes fieles.</a><br><hr>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">                          
                            <div class="panel-body queofrecemoslado"><span class="titulo1">Marketing Digital</span><img src="../img/noticia4.png" alt="Imagen Jornada" class="imagennoticialado img-responsive">
                                <br><a href="nuevasqueofrecemos.php?id=4">Desarrollamos campañas de marketing digital efectivas que promuevan tu negocio y atraigan a un público más amplio. Utilizamos técnicas de SEO, publicidad en redes sociales y email marketing para asegurarnos de que tu mensaje llegue a las personas adecuadas.</a><br><hr>
                            </div>
                            <div class="panel-body"><span class="titulo1">Promoción de Eventos</span><br><img src="../img/noticia5.png" alt="Imagen Jornada" class="imagennoticialado img-responsive">
                                <a href="nuevasqueofrecemos.php?id=5">Te ayudamos a planificar y promocionar tus eventos con estrategias personalizadas que aseguren una alta participación. Diseñamos carteles, flyers y campañas en redes sociales para maximizar la visibilidad de tus eventos y garantizar su éxito.</a><br><hr>
                            </div>
                            <div class="panel-body"><span class="titulo1">Asesoramiento y Soporte Técnico</span><br><img src="../img/noticia6.png" alt="Imagen Jornada" class="imagennoticialado img-responsive">
                                <a href="nuevasqueofrecemos.php?id=6">Ofrecemos soporte técnico continuo y asesoramiento personalizado para asegurarnos de que tu sitio web y tus aplicaciones funcionen sin problemas. Estamos aquí para ayudarte en cada paso, desde la implementación inicial hasta el mantenimiento a largo plazo.</a><br><hr>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
crearPie();
?>   