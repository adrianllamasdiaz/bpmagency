<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$titulo = "BPMagency - Nuestros Clientes";
$fichero = basename(__FILE__);
$directorio = "clientes";

if ($fichero == "index.php") {
    include_once("php/funciones_plantillas.php");
} else {
    include_once("../php/funciones_plantillas.php");
}
crearHeader($directorio, $titulo);
crearMenu($directorio);

include_once("../php/funciones_insertar.php");
?>

<link href="../css/datatables.min.css" rel="stylesheet" type="text/css"/>
<link href="../css/responsive.bootstrap.min.css" rel="stylesheet" type="text/css"/>
<link href="../css/estilo.css" rel="stylesheet" type="text/css"/>
<script src="../js/datatables.min.js" type="text/javascript"></script>
<script src="../js/responsive.bootstrap.min.js" type="text/javascript"></script>

<style>
/* Estilos específicos para la sección de clientes */
#clientes h2 {
    text-align: center;
    color: #ffd500; /* Color dorado */
    margin-bottom: 30px;
}

.redes-sociales {
    display: flex;
    justify-content: space-around;
    flex-wrap: wrap;
    margin-bottom: 30px;
}

.red-social {
    margin: 20px;
    flex: 1 1 300px;
    max-width: 500px;
}
</style>

<!--   Contenedor Principal    -->
<div id="clientes" class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="container-fluid">
                    <div class="row" id="articulos">
                        <br>
                        <div class="panel-body">
                            <h2>Conoce a Nuestros Clientes</h2>
                            <div class="redes-sociales">
                                <div class="red-social">
                                    <!-- Incrustar perfil de Facebook -->
                                    <div class="fb-page" data-href="https://www.facebook.com/profile.php?id=100063550003610" data-tabs="timeline" data-width="500" data-height="700" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true">
                                        <blockquote cite="https://www.facebook.com/profile.php?id=100063550003610" class="fb-xfbml-parse-ignore">
                                            <a href="https://www.facebook.com/profile.php?id=100063550003610">Circus Talavera</a>
                                        </blockquote>
                                    </div>
                                </div>
                                <div class="red-social">
                                    <!-- Incrustar otro perfil de Facebook -->
                                    <div class="fb-page" data-href="https://www.facebook.com/zocco.talavera" data-tabs="timeline" data-width="500" data-height="700" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true">
                                        <blockquote cite="https://www.facebook.com/facebook" class="fb-xfbml-parse-ignore">
                                            <a href="https://www.facebook.com/facebook">Facebook</a>
                                        </blockquote>
                                    </div>
                                </div>
                                <div class="red-social">
                                    <!-- Incrustar otro perfil de Facebook -->
                                    <div class="fb-page" data-href="https://www.facebook.com/elhuerto.talavera" data-tabs="timeline" data-width="500" data-height="700" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true">
                                        <blockquote cite="https://www.facebook.com/instagram" class="fb-xfbml-parse-ignore">
                                            <a href="https://www.facebook.com/instagram">Instagram</a>
                                        </blockquote>
                                    </div>
                                </div>
                            </div>
                            <div class="redes-sociales">
                                <!-- Puedes añadir más perfiles de redes sociales aquí -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
crearPie();
?>

<!-- Cargar SDK de Facebook para incrustar perfiles -->
<div id="fb-root"></div>
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v10.0" nonce="Gcdk50FZ"></script>
