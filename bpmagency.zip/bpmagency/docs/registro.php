<?php

$titulo = "BPMagency - Registro";
$fichero = basename(__FILE__);
$directorio = "registro";

if ($fichero == "index.php") {
    include_once("php/funciones_plantillas.php");
} else {
    include_once("../php/funciones_plantillas.php");
}
crearHeader($directorio, $titulo);
crearMenu($directorio);

include_once("../php/funciones_sesion.php");

if (isset($_POST['enviar'])) {
    registrarUsuario($_POST);
} else {
    ?>

    <!--   Contenedor Principal    -->
    <div class="container">
        <div class="jumbotron">
            <h1 class="text-center">Formulario de Registro</h1>
        </div>
    </div>

    <div class="container">
        <div class="row">
            <div class="col-md-6 text-center">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Instrucciones</h3>
                    </div>
                    <div class="panel-body">
                        <p class="text-justify">
                            Para unirte a BPMagency, deberas introducir un nombre de usuario, email y contraseña.
                            El email que escribas debera ser real, porque lo necesitaras para gestionar tu cuenta.
                            Te recomendamos que utilices contraseña con minusculas, mayusculas, numeros y caracteres especiales
                            para mayor seguridad.<br><center> ¡Bienvenido a BPMagency!</center>
                        </p>
                        <a href="#" class="text-center" onclick="login()">¿Ya tienes cuenta?</a>
                    </div>
                </div>
            </div>
            <div class="col-md-6 text-center">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Introduce tus Datos</h3>
                    </div>
                    <div class="panel-body">
                        <form role="form" id="form1" method="POST" action="registro.php">
                            <div class="form-group">
                                <label>Nombre de Usuario</label>
                                <input class="form-control" type="text" id="nombre" name="nombre_usuario" placeholder="Adrian" required><br><span id="errornom"></span>
                            </div>
                            <div class="form-group">
                                <label>Email</label>
                                <input class="form-control" type="email" id="email" name="email" placeholder="email@correo.com" required><br><span id="errorem"></span>
                            </div>
                            <div class="form-group">
                                <label>Contraseña</label>
                                <input class="form-control" type="password" id="clave1" name="clave1" required><br><span id="errorpa1"></span>
                            </div>
                            <div class="form-group">
                                <label>Repite la Contraseña</label>
                                <input class="form-control" type="password" id="clave2" name="clave2" required><br><span id="errorpa2"></span>
                            </div>
                            <button type="submit" id="enviar" name="enviar" class="btn btn-default btn-success">Enviar</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php }
?>

<?php
crearPie();

function registrarUsuario($datos) {
    $conexion = conexion();

    $nombre_usuario = $datos['nombre_usuario'];
    $email = $datos['email'];
    $clave1 = $datos['clave1'];
    $clave2 = $datos['clave2'];

    if ($clave1 !== $clave2) {
        echo "Las contraseñas no coinciden";
        return;
    }

    $contraseña = password_hash($clave1, PASSWORD_DEFAULT);

    $sql = "INSERT INTO usuarios (nombre_usuario, email, contraseña) VALUES ('$nombre_usuario', '$email', '$contraseña')";

    if ($conexion->query($sql) === TRUE) {
        echo "Usuario registrado exitosamente";
    } else {
        echo "Error: " . $sql . "<br>" . $conexion->error;
    }

    $conexion->close();
}
?>
