<?php
$titulo = "BPMagency - Nuevo Tema";
$directorio = "nuevo_tema";
$fichero = basename(__FILE__);

if ($fichero == "index.php") {
    include_once("php/funciones_plantillas.php");
} else {
    include_once("../php/funciones_plantillas.php");
}
crearHeader($directorio, $titulo);
crearMenu($directorio);

include_once("../php/funciones_insertar.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    insertarTema($_POST);
}
?>

<!--   Contenedor Principal    -->
<div class="container">
    <div class="jumbotron">
        <h1 class="text-center">Crear Nuevo Tema</h1>
    </div>
    <form method="POST" action="nuevo_tema.php">
        <div class="form-group">
            <label for="titulo">Título:</label>
            <input type="text" class="form-control" id="titulo" name="titulo" required>
        </div>
        <div class="form-group">
            <label for="contenido">Contenido:</label>
            <textarea class="form-control" id="contenido" name="contenido" rows="5" required></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Crear Tema</button>
    </form>
</div>

<?php
crearPie();
?>
