<?php
include_once '../php/funciones_sesion.php';
include_once '../php/funciones_insertar.php';

// Verificar si la sesión ya está activa antes de iniciar una nueva sesión
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (isset($_SESSION['usuario']) && isset($_SESSION['usuario_id'])) {
    $tema_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

    if ($tema_id > 0) {
        $conexion = conexion();
        // Verificar si el usuario es el autor del tema o un administrador
        $usuario_id = $_SESSION['usuario_id'];
        $consulta = "SELECT * FROM temas WHERE id = ? AND usuario_id = ?";
        $stmt = $conexion->prepare($consulta);
        $stmt->bind_param("ii", $tema_id, $usuario_id);
        $stmt->execute();
        $resultado = $stmt->get_result();

        if ($resultado->num_rows > 0 || $_SESSION['usuario'] == 'admin') {
            // Borrar las respuestas asociadas al tema
            $consulta = "DELETE FROM respuestas WHERE tema_id = ?";
            $stmt = $conexion->prepare($consulta);
            $stmt->bind_param("i", $tema_id);
            if (!$stmt->execute()) {
                echo "Error al borrar las respuestas del tema: " . $stmt->error;
                exit();
            }

            // Borrar el tema
            $consulta = "DELETE FROM temas WHERE id = ?";
            $stmt = $conexion->prepare($consulta);
            $stmt->bind_param("i", $tema_id);

            if ($stmt->execute()) {
                header("Location: foro.php");
                exit();
            } else {
                echo "Error al borrar el tema: " . $stmt->error;
            }

            $stmt->close();
        } else {
            echo "No tienes permiso para borrar este tema.";
        }

        $conexion->close();
    } else {
        echo "ID de tema no válido.";
    }
} else {
    echo "Debes iniciar sesión para borrar un tema.";
}
?>
