<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$titulo = "BPMagency - planes";
$fichero = basename(__FILE__);
$directorio = "planes";

if ($fichero == "index.php") {
    include_once("php/funciones_plantillas.php");
} else {
    include_once("../php/funciones_plantillas.php");
}
crearHeader($directorio, $titulo);
crearMenu($directorio);

include_once("../php/funciones_insertar.php");
?>

<link href="../css/datatables.min.css" rel="stylesheet" type="text/css"/>
<link href="../css/responsive.bootstrap.min.css" rel="stylesheet" type="text/css"/>
<link href="../css/estilo.css" rel="stylesheet" type="text/css"/>
<script src="../js/datatables.min.js" type="text/javascript"></script>
<script src="../js/responsive.bootstrap.min.js" type="text/javascript"></script>

<style>
/* Estilos específicos para la tabla de planes */
#planes h2 {
    text-align: center;
    color: #ffd500; /* Color dorado */
    margin-bottom: 30px;
}

#planes .table {
    width: 100%;
    margin-bottom: 1rem;
    color: #fff; /* Letra blanca */
    border-collapse: collapse;
    background-color: #343a40; /* Fondo gris oscuro */
    border: 2px solid #ffd500; /* Borde dorado */
    text-transform: uppercase; /* Letra en mayúsculas */
}

#planes .table thead th {
    background-color: #343a40;
    color: #fff;
    border-bottom: 3px solid #ffd500; /* Borde inferior dorado */
    padding: 12px;
    text-align: center;
}

#planes .table tbody td {
    padding: 12px;
    border-top: 1px solid #dee2e6;
    text-align: center;
    color: #fff; /* Letra blanca */
}

#planes .table tbody tr:nth-of-type(odd) {
    background-color: #495057; /* Fondo gris medio */
}

#planes .table tbody tr:hover {
    background-color: #6c757d; /* Resaltar la celda al pasar el cursor */
}

/* Columnas de los planes */
#planes .table tbody td:first-child {
    font-weight: bold;
    background-color: #6a1b9a; /* Morado */
}

#planes .table tbody td:nth-child(2) {
    background-color: #6a1b9a; /* Morado */
}

#planes .table tbody td:nth-child(3) {
    background-color: #009688; /* Verde */
}

#planes .table tbody td:nth-child(4) {
    background-color: #d32f2f; /* Rojo */
}

#planes .table tbody td:nth-child(5) {
    background-color: #fbc02d; /* Amarillo */
}

/* Ajuste para la tabla de planes */
#planes .table th, #planes .table td {
    border: 1px solid #ffd500; /* Borde dorado */
}
</style>

<!--   Contenedor Principal    -->
<div id="planes" class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="container-fluid">
                    <div class="row" id="articulos">
                        <br>
                        <div class="panel-body">
                            <h2>Elige el Plan Perfecto para tu Negocio</h2>
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>Características</th>
                                        <th>Básico</th>
                                        <th>Estándar</th>
                                        <th>Pro</th>
                                        <th>Creación de Web</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Diseño Web Personalizado</td>
                                        <td style="background-color: #6a1b9a;">✔</td> <!-- Morado -->
                                        <td style="background-color: #009688;">✔</td> <!-- Verde -->
                                        <td style="background-color: #d32f2f;">✔</td> <!-- Rojo -->
                                        <td style="background-color: #fbc02d;" rowspan="7">€500</td> <!-- Amarillo -->
                                    </tr>
                                    <tr>
                                        <td>Gestión de Redes Sociales</td>
                                        <td style="background-color: #6a1b9a;">✘</td>
                                        <td style="background-color: #009688;">✔</td>
                                        <td style="background-color: #d32f2f;">✔</td>
                                    </tr>
                                    <tr>
                                        <td>SEO Básico</td>
                                        <td style="background-color: #6a1b9a;">✘</td>
                                        <td style="background-color: #009688;">✔</td>
                                        <td style="background-color: #d32f2f;">✔</td>
                                    </tr>
                                    <tr>
                                        <td>Promoción de Eventos</td>
                                        <td style="background-color: #6a1b9a;">✘</td>
                                        <td style="background-color: #009688;">✘</td>
                                        <td style="background-color: #d32f2f;">✔</td>
                                    </tr>
                                    <tr>
                                        <td>Soporte Técnico</td>
                                        <td style="background-color: #6a1b9a;">Email</td>
                                        <td style="background-color: #009688;">Email y Teléfono</td>
                                        <td style="background-color: #d32f2f;">Email, Teléfono y Chat</td>
                                    </tr>
                                    <tr>
                                        <td>Actualizaciones</td>
                                        <td style="background-color: #6a1b9a;">Mensuales</td>
                                        <td style="background-color: #009688;">Quincenales</td>
                                        <td style="background-color: #d32f2f;">Semanales</td>
                                    </tr>
                                    <tr>
                                        <td>Precio</td>
                                        <td style="background-color: #6a1b9a;">€150/mes</td>
                                        <td style="background-color: #009688;">€300/mes</td>
                                        <td style="background-color: #d32f2f;">€450/mes</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
crearPie();
?>
