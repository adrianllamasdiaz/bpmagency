<?php
$titulo = "BPMagency - Foro";
$directorio = "foro";

if (basename(__FILE__) == "index.php") {
    include_once("php/funciones_plantillas.php");
} else {
    include_once("../php/funciones_plantillas.php");
}
crearHeader($directorio, $titulo);
crearMenu($directorio);

include_once("../php/funciones_insertar.php");

// Verificar si la sesión ya está activa antes de iniciar una nueva sesión
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (!empty($_SESSION['usuario'])) { 
    $varsesion = $_SESSION['usuario'];
    $usuario_id = $_SESSION['usuario_id'];
}

if (!isset($varsesion) || empty($varsesion)) {
    ?>

    <div class="container">
        <div class="jumbotron" id="forobloqueado">
            <h1 class="text-center">Contenido Bloqueado</h1>
            <p class="text-center" id="avisoforo"> Debes estar registrado para acceder a esta zona de la web</p>
        </div>
    </div>

    <?php
} else {
    ?>

    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default" id="articulos">
                    <a id="volvertemas" class="btn btn-primary btn-success" href="nuevo_tema.php" role="button">Crear Nuevo Tema</a>
                    <br><br>
                    <div class="container" id="foro"> 
                        <div class="row" id="cabecera_foro">
                            <div class="col-md-4">
                                <div class="panel-body text-center"><strong>Tema</strong></div>
                            </div>
                            <div class="col-md-2">
                                <div class="panel-body text-center"><strong>Autor</strong></div>
                            </div>
                            <div class="col-md-2">
                                <div class="panel-body text-center"><strong>Fecha</strong></div>
                            </div>
                            <div class="col-md-2">
                                <div class="panel-body text-center"><strong>Respuestas</strong></div>
                            </div>
                            <div class="col-md-2">
                                <div class="panel-body text-center"><strong>Acciones</strong></div>
                            </div>
                        </div>
                        <?php
                        $conexion = conexion();
                        $consulta = "SELECT b.id, b.titulo, b.fecha_creacion, a.nombre_usuario AS autor, a.id AS autor_id, 
                                     (SELECT COUNT(*) FROM respuestas r WHERE r.tema_id = b.id) AS num_respuestas
                                     FROM temas b
                                     JOIN usuarios a ON b.usuario_id = a.id
                                     ORDER BY b.fecha_creacion DESC";
                        $resultados = mysqli_query($conexion, $consulta);

                        if ($resultados) {
                            while ($fila = mysqli_fetch_assoc($resultados)) {
                                echo '<div class="row">';
                                echo '<div class="col-md-4">';
                                echo '<div class="panel-body text-center"><a href="ver_tema.php?id=' . $fila['id'] . '">' . htmlspecialchars($fila['titulo']) . '</a></div>';
                                echo '</div>';
                                echo '<div class="col-md-2">';
                                echo '<div class="panel-body text-center">' . htmlspecialchars($fila['autor']) . '</div>';
                                echo '</div>';
                                echo '<div class="col-md-2">';
                                echo '<div class="panel-body text-center">' . htmlspecialchars($fila['fecha_creacion']) . '</div>';
                                echo '</div>';
                                echo '<div class="col-md-2">';
                                echo '<div class="panel-body text-center">' . htmlspecialchars($fila['num_respuestas']) . '</div>';
                                echo '</div>';
                                echo '<div class="col-md-2 text-center">';
                                if ($fila['autor_id'] == $usuario_id || $_SESSION['usuario'] == 'admin') {
                                    echo '<a href="borrar_tema.php?id=' . $fila['id'] . '" class="btn btn-danger btn-sm">Borrar</a>';
                                }
                                echo '</div>';
                                echo '</div>';
                            }
                        } else {
                            echo "Error en la consulta: " . mysqli_error($conexion);
                        }

                        mysqli_free_result($resultados);
                        mysqli_close($conexion);
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php } ?>

<?php
crearPie();
?>
