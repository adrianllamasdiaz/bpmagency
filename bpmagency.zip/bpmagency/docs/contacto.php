<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$titulo = "Contacto - BPMagency"; // Esto establece el titulo de la pagina actual
$directorio = "contacto"; // Variable que establece el nombre del directorio
$fichero = basename(__FILE__); // Esta función te da el nombre y extensión del fichero actual 

// Este if comprueba donde estamos situados, si es index.php llama al fichero de funciones
// desde una ruta, si es cualquier otro fichero, lo llama desde otra ruta
if ($fichero == "contacto.php") {
    include_once("../php/funciones_plantillas.php");
} else {
    include_once("../../php/funciones_plantillas.php");
}

crearHeader($directorio, $titulo); // Llama a la función que crea la plantilla del header en todas las páginas
crearMenu($directorio); // Llama a la función que crea la plantilla del menú en todas las páginas
?>

<!-- Contenedor Principal -->
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-body introduccion">
                    <p><span class="titulo">Contacto</span></p>
                    <p>¿Interesado en nuestros servicios? Contáctanos y descubre cómo podemos ayudarte a transformar tu presencia digital.</p>
                    <a href="https://mail.google.com/mail/?view=cm&fs=1&to=info@bpmagency.com" target="_blank" class="btn btn-primary">Enviar Correo a BPMagency</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
crearPie(); // Llama a la función que crea la plantilla del footer en todas las páginas
?>
