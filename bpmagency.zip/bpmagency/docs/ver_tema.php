<?php
$titulo = "BPMagency - Ver Tema";
$directorio = "ver_tema";
$fichero = basename(__FILE__);

if ($fichero == "index.php") {
    include_once("php/funciones_plantillas.php");
} else {
    include_once("../php/funciones_plantillas.php");
}
crearHeader($directorio, $titulo);
crearMenu($directorio);

include_once("../php/funciones_insertar.php");

// Verificar si la sesión ya está activa antes de iniciar una nueva sesión
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Obtener el ID del tema de la URL
$tema_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Verificar si se proporcionó un ID de tema válido
if ($tema_id > 0) {
    $tema = obtenerTema($tema_id);
    $respuestas = obtenerRespuestas($tema_id);
} else {
    echo "ID de tema no válido.";
    exit();
}
?>

<!-- Contenedor Principal -->
<div class="container">
    <div class="jumbotron">
        <h1 class="text-center"><?php echo htmlspecialchars($tema['titulo']); ?></h1>
        <p><?php echo nl2br(htmlspecialchars($tema['contenido'])); ?></p>
        <p><strong>Autor:</strong> <?php echo htmlspecialchars($tema['nombre_usuario']); ?></p>
        <p><strong>Fecha de creación:</strong> <?php echo htmlspecialchars($tema['fecha_creacion']); ?></p>
    </div>

    <div class="panel panel-default">
        <div class="panel-heading">
            <h3 class="panel-title">Respuestas</h3>
        </div>
        <div class="panel-body">
            <?php
            if ($respuestas) {
                foreach ($respuestas as $respuesta) {
                    echo '<div class="media">';
                    echo '<div class="media-body">';
                    echo '<h4 class="media-heading">' . htmlspecialchars($respuesta['nombre_usuario']) . ' <small><i>' . htmlspecialchars($respuesta['fecha_creacion']) . '</i></small></h4>';
                    echo '<p>' . nl2br(htmlspecialchars($respuesta['contenido'])) . '</p>';
                    echo '</div>';
                    echo '</div>';
                }
            } else {
                echo '<p>No hay respuestas.</p>';
            }
            ?>
        </div>
    </div>

    <?php if (!empty($_SESSION['usuario'])): ?>
        <form method="POST" action="nueva_respuesta.php">
            <div class="form-group">
                <label for="contenido">Agregar Respuesta:</label>
                <textarea class="form-control" id="contenido" name="contenido" rows="5" required></textarea>
            </div>
            <input type="hidden" name="tema_id" value="<?php echo $tema_id; ?>">
            <button type="submit" class="btn btn-primary">Responder</button>
        </form>
    <?php else: ?>
        <p>Debes iniciar sesión para responder.</p>
    <?php endif; ?>
</div>

<?php
crearPie();
?>
