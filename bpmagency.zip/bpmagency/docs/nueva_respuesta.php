<?php
include_once '../php/funciones_insertar.php';

// Verificar si la sesión ya está activa antes de iniciar una nueva sesión
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $contenido = $_POST['contenido'];
    $tema_id = intval($_POST['tema_id']);
    $usuario_id = $_SESSION['usuario_id'];

    $conexion = conexion();
    $stmt = $conexion->prepare("INSERT INTO respuestas (contenido, tema_id, usuario_id) VALUES (?, ?, ?)");
    $stmt->bind_param("sii", $contenido, $tema_id, $usuario_id);

    if ($stmt->execute()) {
        header("Location: ver_tema.php?id=$tema_id");
        exit();
    } else {
        echo "Error al agregar respuesta: " . $stmt->error;
    }

    $stmt->close();
    $conexion->close();
}
?>
