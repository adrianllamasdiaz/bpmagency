/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

//Esta funcion sirve para sustituir el contenido de articulos, por el nuevo contenido de la primera columna Bienvenida
function boton() {
document.getElementById('articulos').innerHTML = '<div class="col-md-12"><br><button type="button" class="botonranking btn btn-default btn-success" onclick="recargar(this)">Volver</button><div class="panel-body introduccion"><p><span class="titulo">BIENVENIDO !</span></p>\n\
\n\<p>\n\
<span class="titulo1">¡BPMagency ES TU PAGINA!</span></p></div>\n\
<div class="panel-body text-justify"><p>En BPMagency nos especializamos en crear y gestionar páginas web y redes sociales para locales de ocio nocturno. Nuestro objetivo es ayudarte a destacar en el mundo digital, atrayendo más clientes y aumentando tu visibilidad online. Con nuestros servicios de diseño web, gestión de eventos y estrategias en redes sociales, llevamos tu negocio al siguiente nivel. Descubre cómo podemos transformar tu presencia digital y ofrecer una experiencia única a tus clientes. y mucho mas...</p>\n\
.</p>\n\
<br><img src="./img/1.png" alt="Imagen Portada" class="imageninicio img-responsive"></div></div>';
        }

//Esta funcion sirve para sustituir el contenido de articulos, por el nuevo contenido de la segunda columna Jornada
function boton1() {
document.getElementById('articulos').innerHTML = '<div class="col-md-12"><br><button type="button" class="botonranking btn btn-default btn-success" onclick="recargar(this)">Volver</button><div class="panel-body introduccion"><p><span class="titulo">TODO LO QUE NECESITAS</span></p> <p><span class="titulo1"></span></p></div><div class="panel-body text-justify"><img src="./img/2.png" alt="Imagen Horario" class="imageninicio img-responsive"><br><p> Creamos un diseño único que refleje la identidad y el estilo de tu local, asegurando una experiencia de usuario excepcional. Integramos funciones específicas como gestión de reservados, entradas para eventos y listas personalizadas para satisfacer tus necesidades. Mejoramos tu visibilidad en los motores de búsqueda para atraer más visitantes a tu sitio web, impulsando tu negocio. Aseguramos que tu web se vea y funcione perfectamente en todos los dispositivos, desde móviles hasta ordenadores de escritorio. Te ofrecemos mantenimiento continuo y soporte técnico para que tu sitio web siempre esté al día y en perfecto funcionamiento.</p></div></div>';}

//Esta funcion nos permite validar si el usuario ha acertado en la pagina del juego
function acierta(id, valido1, valido2, url, carta, error) {
var valor = document.getElementById(id).value.toLowerCase();
        if (valor == valido1 || valor == valido2) {
document.getElementById(error).innerHTML = '';
        document.getElementById(carta).innerHTML = '<img src="' + url + '" class="imagenposicion"><br>';
        } else {
document.getElementById(error).innerHTML = 'Lo siento, pero no has acertado el jugador que se esconde tras la carta\n\
                                                        debe volver a intentarlo con otro jugador';
        }
}

//Esta funcion valida que todos los campos del formulario, esten correctos
function validar() {
var nombre = document.getElementById('nombre').value;
        var email = document.getElementById('email').value;
        var password = document.getElementById('clave1').value;
        var password2 = document.getElementById('clave2').value;
        if (!isNaN(nombre)) {
alert('Debes introducir un nombre valido');
        return false;
        } else if (!isNaN(email)) {
alert('Debes introducir un email valido');
        return false;
        } else if (!isNaN(password)) {
alert('Debes introducir una contraseña valida');
        return false;
        } else if (!isNaN(password2)) {
alert('Debes introducir una contraseña valida');
        return false;
        }
}

//Esta funcion valida que el nombre en el formulario, sea correcto
function valida() {
var nombre = document.getElementById('nombre').value;
        document.getElementById('errornom').innerHTML = '';
        if (!isNaN(nombre)) {
document.getElementById('errornom').innerHTML = ' * El nombre no puede contener unicamente caracteres numéricos';
        document.getElementById('nombre').focus();
        document.getElementById('nombre').value = '';
        } else if (nombre.length <= 3) {
document.getElementById('errornom').innerHTML = ' * Debes introducir un nombre con 4 caracteres o mas';
        document.getElementById('nombre').focus();
        document.getElementById('nombre').value = '';
        } else if (nombre.length >= 50) {
document.getElementById('errornom').innerHTML = ' * Debes introducir un nombre con menos de 50 caracteres';
        document.getElementById('nombre').focus();
        document.getElementById('nombre').value = '';
        } else {
//document.getElementById('nombre').readOnly = true; Esta opcion hace que al introducir un nombre correcto el usuario
//no pueda modificar ese campo, he decidido desactivarlo, aunque me parece una buena funcion y por eso la he dejado en
//el codigo ya que podria ser una opcion interesante para utilizarse.
document.getElementById('errornom').innerHTML = ' ';
        }
}

//Esta funcion valida que el email en el formulario, sea correcto
function valida1() {
var email = document.getElementById('email').value;
        document.getElementById('errorem').innerHTML = '';
        expresion = /\w+@\w+\.+[a-z]/;
        if (!expresion.test(email)) {
document.getElementById('errorem').innerHTML = ' * Debes introducir un email con el formato correcto, similar al ejemplo';
        document.getElementById('email').focus();
        document.getElementById('email').value = '';
        } else {
//document.getElementById('email').readOnly = true;
document.getElementById('errorem').innerHTML = ' ';
        }
}

//Esta funcion valida que la contraseña en el formulario, sea correcta
function valida2() {
var password1 = document.getElementById('clave1').value;
        document.getElementById('errorpa1').innerHTML = '';
        if (password1.length < 8) {
document.getElementById('errorpa1').innerHTML = '  La contraseña debe contener mas de 8 caracteres<br><br>';
        document.getElementById('clave1').focus();
        document.getElementById('clave1').value = '';
        } else if (password1.length > 50) {
document.getElementById('errorpa1').innerHTML = '  La contraseña debe contener menos de 50 caracteres<br><br>';
        document.getElementById('clave1').focus();
        document.getElementById('clave1').value = '';
        } else {
//document.getElementById('clave1').readOnly = true;
document.getElementById('errorpa1').innerHTML = ' ';
        }
}

//Esta funcion valida que la contraseña sea la misma en ambas opciones
function valida3() {
var password1 = document.getElementById('clave1').value;
        var password2 = document.getElementById('clave2').value;
        document.getElementById('errorpa2').innerHTML = '';
        if (password1 != password2) {
document.getElementById('errorpa2').innerHTML = '  Ambas contraseñas deben coincidir<br><br>';
        document.getElementById('clave2').focus();
        document.getElementById('clave2').value = '';
        } else {
//document.getElementById('clave2').readOnly = true;
document.getElementById('errorpa2').innerHTML = ' ';
        }
}

//Esta funcion simplemente recarga la pagina en la que nos encontramos, esta puesta aqui, para ser llamada en 
//los momentos que necesitemos
function recargar() {
location.reload();
}

//Esta funcion, oculta el div de inicio de sesion
function login() {
var oculto = document.getElementById('login'); //Esta linea almacena el div llamado login en la variable oculto
        oculto.style.display = (oculto.style.display == 'none') ? 'inline' : 'none'; //Y esta linea, sustituye el parametro display none, por inline
}

//Esta funcion valida que el titulo en el formulario, sea correcto
function valida_titulo() {
var titulo = document.getElementById('tituloform').value;
        document.getElementById('errornom').innerHTML = '';
        if (!isNaN(titulo)) {
document.getElementById('errornom').innerHTML = ' * El titulo no puede contener unicamente caracteres numéricos<br><br>';
        document.getElementById('tituloform').focus();
        document.getElementById('tituloform').value = '';
        } else if (titulo.length <= 3) {
document.getElementById('errornom').innerHTML = ' * Debes introducir un titulo con 4 caracteres o mas<br><br>';
        document.getElementById('tituloform').focus();
        document.getElementById('tituloform').value = '';
        } else if (titulo.length >= 30) {
document.getElementById('errornom').innerHTML = ' * Debes introducir un titulo con menos de 30 caracteres<br><br>';
        document.getElementById('tituloform').focus();
        document.getElementById('tituloform').value = '';
        } else {
document.getElementById('tituloform').readOnly = true;
        document.getElementById('errornom').innerHTML = ' ';
        }
}