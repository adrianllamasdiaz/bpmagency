<?php
include_once 'funciones_sesion.php'; // Incluir el archivo de conexión y funciones de sesión

function mostrarForo($usuario) {
    $conexion = conexion();
    $consulta = "SELECT b.id, b.titulo, b.fecha_creacion, a.nombre_usuario AS autor, 
                 (SELECT COUNT(*) FROM respuestas r WHERE r.tema_id = b.id) AS num_respuestas
                 FROM temas b
                 JOIN usuarios a ON b.usuario_id = a.id
                 ORDER BY b.fecha_creacion DESC";
    $resultados = mysqli_query($conexion, $consulta);
    
    if ($resultados) {
        while ($fila = mysqli_fetch_assoc($resultados)) {
            echo '<div class="row">';
            echo '<div class="col-md-4">';
            echo '<div class="panel-body text-center"><a href="ver_tema.php?id=' . $fila['id'] . '">' . htmlspecialchars($fila['titulo']) . '</a></div>';
            echo '</div>';
            echo '<div class="col-md-3">';
            echo '<div class="panel-body text-center">' . htmlspecialchars($fila['autor']) . '</div>';
            echo '</div>';
            echo '<div class="col-md-3">';
            echo '<div class="panel-body text-center">' . htmlspecialchars($fila['fecha_creacion']) . '</div>';
            echo '</div>';
            echo '<div class="col-md-2">';
            echo '<div class="panel-body text-center">' . htmlspecialchars($fila['num_respuestas']) . '</div>';
            echo '</div>';
            echo '</div>';
        }
    } else {
        echo "Error en la consulta: " . mysqli_error($conexion);
    }

    mysqli_free_result($resultados);
    mysqli_close($conexion);
}

function registrarUsuario($datos) {
    $conexion = conexion();

    $nombre_usuario = $datos['nombre'];
    $email = $datos['email'];
    $contraseña = password_hash($datos['clave1'], PASSWORD_DEFAULT);

    $stmt = $conexion->prepare("INSERT INTO usuarios (nombre_usuario, email, contraseña) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $nombre_usuario, $email, $contraseña);

    if ($stmt->execute()) {
        echo "Usuario registrado exitosamente.";
    } else {
        echo "Error al registrar usuario: " . $stmt->error;
    }

    $stmt->close();
    mysqli_close($conexion);
}

function insertarTema($datos) {
    $conexion = conexion();

    if (isset($datos['titulo']) && isset($datos['contenido'])) {
        $titulo = $datos['titulo'];
        $contenido = $datos['contenido'];
        $usuario_id = $_SESSION['usuario_id'];

        $stmt = $conexion->prepare("INSERT INTO temas (titulo, contenido, usuario_id) VALUES (?, ?, ?)");
        $stmt->bind_param("ssi", $titulo, $contenido, $usuario_id);

        if ($stmt->execute()) {
            echo "Tema creado exitosamente.";
        } else {
            echo "Error al crear tema: " . $stmt->error;
        }

        $stmt->close();
        mysqli_close($conexion);
    } else {
        echo "Faltan datos para crear el tema. Datos recibidos: " . print_r($datos, true);
    }
}

function obtenerTema($tema_id) {
    $conexion = conexion();
    $stmt = $conexion->prepare("SELECT t.*, u.nombre_usuario FROM temas t JOIN usuarios u ON t.usuario_id = u.id WHERE t.id = ?");
    $stmt->bind_param("i", $tema_id);
    $stmt->execute();
    $resultado = $stmt->get_result();
    $tema = $resultado->fetch_assoc();
    $stmt->close();
    $conexion->close();
    return $tema;
}

function obtenerRespuestas($tema_id) {
    $conexion = conexion();
    $stmt = $conexion->prepare("SELECT r.*, u.nombre_usuario FROM respuestas r JOIN usuarios u ON r.usuario_id = u.id WHERE r.tema_id = ? ORDER BY r.fecha_creacion ASC");
    $stmt->bind_param("i", $tema_id);
    $stmt->execute();
    $resultado = $stmt->get_result();
    $respuestas = $resultado->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    $conexion->close();
    return $respuestas;
}
?>
