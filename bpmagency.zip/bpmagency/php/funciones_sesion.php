<?php

function conexion() {
    // Crea la conexión con la base de datos
    $conexion = mysqli_connect("localhost", "root", "", "bpm")
        or die("No se puede conectar con el servidor");
    return $conexion;
}

function loguearse($directorio, $datos) {
    $conexion = conexion();

    // Asegurarse de que ambos campos están presentes en el arreglo
    if (!empty($datos['nombre_usuario']) && !empty($datos['contraseña'])) {
        $usuario = $datos['nombre_usuario'];
        $contraseña = $datos['contraseña'];

        // Preparar y ejecutar la consulta SQL para evitar inyecciones SQL
        $stmt = $conexion->prepare("SELECT * FROM usuarios WHERE nombre_usuario = ?");
        $stmt->bind_param("s", $usuario);
        $stmt->execute();
        $resultado = $stmt->get_result();

        if ($resultado->num_rows > 0) {
            $fila = $resultado->fetch_assoc();
            if (password_verify($contraseña, $fila['contraseña'])) {
                session_start();
                $_SESSION['usuario'] = $usuario;
                $_SESSION['usuario_id'] = $fila['id'];
                header("Location: /bpmagency/index.php"); // Redireccionar a index.php
                exit();
            } else {
                echo "Contraseña incorrecta";
            }
        } else {
            echo "No existe un usuario con ese nombre";
        }
        $stmt->close();
    } else {
        echo "Por favor complete todos los campos.";
        echo " Datos recibidos: " . print_r($datos, true);
    }
}

function logout() {
    session_start();
    session_unset();
    session_destroy(); // Esta función cierra o destruye la sesión iniciada
}
?>
